import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import csv


df = pd.read_csv('data.csv')
#df.head()
df_sort=df.sort_values(by=['output'],ascending=False)
P=[]
R=[]
tpr=[]
fpr=[]
last=0
sum=0
for index,rows in df_sort.iterrows():
    v=rows['output']
    tp=0
    fp=0
    fn=0
    tn=0
    if v!=last:
        for index,row in df_sort.iterrows():
            if row['label']==1:
                if row['output']>=v:
                    tp+=1
                else:
                    fn+=1
            else:
                if row['output']>=v:
                    fp+=1
                else:
                    tn+=1
        P.append(tp/(tp+fp))
        R.append(tp/(tp+fn))
        tpr.append(tp/(tp+fn))
        fpr.append(fp/(fp+tn))
    last=v


for i in range(0,len(tpr)-2):
    sum+=(fpr[i+1]-fpr[i])*(tpr[i]+tpr[i+1])/2

print(sum)

plt.plot(R, P)
plt.figure(num="PR+ROC", figsize=(6, 4), facecolor="white", edgecolor="black")
plt.plot(fpr,tpr)
plt.show()

